// Validation script for the form
function showPwd() {
    var x = document.getElementById("pwdInput");
    var s = document.getElementById("show");               
    var h = document.getElementById("hide");
    var d = document.getElementById("danger2");        
    if (x.type === "password") {
        x.type = 'text';
        s.style.display = 'none';
        h.style.display = 'inline';
        d.style.display = 'none';
    } else {
        x.type = 'password';
        s.style.display = 'inline';
        h.style.display = 'none';
        d.style.display = 'none';
    }   
}
function ValidateEmail(inputText, inputPwd)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(inputText.value.match(mailformat) && inputPwd.value ==="password")
{
    window.location.href = "./signedin.html";
return true;
}
else
{
var x = document.getElementById("emailInput");
var y = document.getElementById("pwdInput")
var d1 = document.getElementById("danger1");  
var d2 = document.getElementById("danger2");  
var s = document.getElementById("show");               
var h = document.getElementById("hide");  
s.style.display = 'none';
h.style.display = "none";
d1.style.display = "inline";
d2.style.display = "inline";
x.classList.add('invalid');
y.classList.add('invalid');
return false;
}
}